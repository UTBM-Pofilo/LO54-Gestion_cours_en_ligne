package fr.utbm.lo54.project.core.entity;

public interface IEntity {
}
